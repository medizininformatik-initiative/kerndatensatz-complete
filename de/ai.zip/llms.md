# de.medizininformatikinitiative.kerndatensatz.complete#2027.0.0-ballot.19: MII Kerndatensatz Complete(de)

## Pages

* [](index.md)
* [Testabdeckung](testabdeckung.md)
* [Migration von v2026](migration.md)
* [Ballotierung 2027.0.0](ballot.md)
* [Versionierung](versionierung.md)
* [Artefaktübersicht](artifacts.md)
* [Entwicklungsstack](entwicklungsstack.md)
* [](validate.md)

## Resources

### CapabilityStatements

* [MII CPS Kerndatensatz Complete CapabilityStatement](CapabilityStatement-mii-cps-kerndatensatz-complete.md)

### ConceptMaps

* [MII ICU Canonicals auf ISiK 6 (Governance-Uebergang)](ConceptMap-mii-cm-kds-icu-isik6-canonicals.md)
* [MII KDS Profil-Canonicals 2026 auf 2027](ConceptMap-mii-cm-kds-profile-canonicals-2026-2027.md)
* [MII KDS ValueSet-Canonicals 2026 auf 2027](ConceptMap-mii-cm-kds-vs-canonicals-2026-2027.md)

### ImplementationGuides

* [MII Kerndatensatz Complete](ImplementationGuide-de.medizininformatikinitiative.kerndatensatz.complete.md)
