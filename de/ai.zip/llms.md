# de.medizininformatikinitiative.kerndatensatz.complete#2027.0.0-ballot.19: MII Kerndatensatz Complete(de)

## Pages

* [Home](index.md)
* [Versionierung](versionierung.md)
* [Testabdeckung](testabdeckung.md)
* [Migration](migration.md)
* [Artefaktübersicht](artifacts.md)
* [Ballot](ballot.md)

## Resources

### CapabilityStatements

* [MII CPS Kerndatensatz Complete CapabilityStatement](CapabilityStatement-mii-cps-kerndatensatz-complete.md)

### ConceptMaps

* [MII KDS Profil-Canonicals 2026 auf 2027](ConceptMap-mii-cm-kds-profile-canonicals-2026-2027.md)
* [MII KDS ValueSet-Canonicals 2026 auf 2027](ConceptMap-mii-cm-kds-vs-canonicals-2026-2027.md)

### ImplementationGuides

* [MII Kerndatensatz Complete](ImplementationGuide-de.medizininformatikinitiative.kerndatensatz.complete.md)
