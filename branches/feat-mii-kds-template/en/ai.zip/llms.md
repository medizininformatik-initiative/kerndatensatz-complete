# de.medizininformatikinitiative.kerndatensatz.complete#2027.0.0-ballot.19: MII Kerndatensatz Complete(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Ballot](ballot.md)

## Resources

### CapabilityStatements

* [MII CPS Kerndatensatz Complete CapabilityStatement](CapabilityStatement-mii-cps-kerndatensatz-complete.md)

### ImplementationGuides

* [MII Kerndatensatz Complete](ImplementationGuide-de.medizininformatikinitiative.kerndatensatz.complete.md)
